import * as dotenv from 'dotenv';
dotenv.config();

/**
 * Centralized, configurable test data - nothing below is hardcoded inline in specs.
 * Values come from environment variables (.env) so the same suite can run against
 * different test accounts / environments without touching code.
 */
export const TestData = {
  baseUrl: process.env.BASE_URL || 'https://tenxyou.com',
  phoneNumber: process.env.TEST_PHONE_NUMBER || '7879103075',
  otp: process.env.TEST_OTP || '1234',
  useMockedOtp: (process.env.USE_MOCKED_OTP ?? 'true').toLowerCase() === 'true',

  // A known, stable product used across cart/persistence/multi-session tests.
  product: {
    path: '/product/native-bombay-blues-white-blue',
    name: 'Native – Bombay Blues Lifestyle Sneaker',
    size: '10',
  },

  // Randomizes per test run so parallel/re-runs don't collide on shared state.
  randomSize(): string {
    const sizes = ['6', '7', '8', '9', '10', '11', '12'];
    return sizes[Math.floor(Math.random() * sizes.length)];
  },
};
