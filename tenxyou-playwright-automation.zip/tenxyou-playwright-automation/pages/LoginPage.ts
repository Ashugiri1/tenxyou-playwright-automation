import { Page, Locator, expect } from '@playwright/test';
import { BasePage } from './BasePage';

/**
 * LoginPage
 * tenxyou.com uses a phone-number + OTP login flow (powered by "GoKwik"), triggered from
 * the header account icon. See docs/SELECTOR_NOTES.md for how these locators were derived
 * and how to re-validate them with `npm run codegen`.
 */
export class LoginPage extends BasePage {
  readonly accountIcon: Locator;
  readonly phoneInput: Locator;
  readonly termsCheckbox: Locator;
  readonly submitButton: Locator;
  readonly otpHeading: Locator;
  readonly otpBoxes: Locator;
  readonly verifyButton: Locator;
  readonly resendText: Locator;
  readonly loggedInAccountMenu: Locator;

  constructor(page: Page) {
    super(page);
    // Header "account" icon (person outline) - opens the login modal
    this.accountIcon = page.locator('header').getByRole('button', { name: /account|profile|login/i })
      .or(page.locator('[aria-label*="account" i], [class*="account" i]').first());

    this.phoneInput = page.getByPlaceholder(/Enter Phone Number/i);
    this.termsCheckbox = page.getByRole('checkbox');
    this.submitButton = page.getByRole('button', { name: /^SUBMIT$/i });

    this.otpHeading = page.getByText(/OTP VERIFICATION/i);
    // The 4 OTP boxes are individual single-character inputs rendered right after the heading.
    this.otpBoxes = page.locator('input[type="text"], input[type="tel"], input[type="number"]')
      .filter({ hasNot: page.locator('[placeholder]') });
    this.verifyButton = page.getByRole('button', { name: /^VERIFY$/i });
    this.resendText = page.getByText(/Resend OTP in/i);

    this.loggedInAccountMenu = page.locator('[class*="account" i], [data-testid*="account" i]').first();
  }

  async openLoginModal() {
    await this.accountIcon.click();
    await expect(this.phoneInput).toBeVisible();
  }

  async enterPhoneNumber(phone: string) {
    await this.phoneInput.fill(phone);
    // Accept T&Cs if the checkbox is present and not already checked
    if (await this.termsCheckbox.count()) {
      const checked = await this.termsCheckbox.first().isChecked().catch(() => false);
      if (!checked) await this.termsCheckbox.first().check({ force: true }).catch(() => {});
    }
  }

  async submitPhoneNumber() {
    await this.waitForApiResponse(/otp|send.?otp|generate/i, async () => {
      await this.submitButton.click();
    });
    await expect(this.otpHeading).toBeVisible();
  }

  /**
   * Fills the 4 individual OTP boxes. Real production OTP is a live SMS code that Playwright
   * cannot read - this path is only usable in a real run if a human supplies the code, or if
   * the environment has a whitelisted test number with a static/known OTP.
   */
  async enterOtp(otp: string) {
    const digits = otp.split('');
    const boxes = this.otpBoxes;
    await expect(boxes.first()).toBeVisible();
    for (let i = 0; i < digits.length; i++) {
      await boxes.nth(i).fill(digits[i]);
    }
  }

  async verify() {
    const response = await this.waitForApiResponse(/verify|otp/i, async () => {
      await this.verifyButton.click();
    });
    return response;
  }

  /**
   * PREFERRED path for CI/automation: intercepts the OTP-verify network call and mocks a
   * successful response so the full login flow is deterministic and does not depend on a
   * real SMS. This keeps the rest of the suite (cart, persistence, multi-session) runnable
   * end-to-end without manual intervention. See docs/AI_USAGE.md and README for rationale.
   */
  async loginWithMockedOtp(phone: string) {
    await this.openLoginModal();
    await this.enterPhoneNumber(phone);

    await this.page.route(/verify.?otp|otp.?verify/i, async (route) => {
      await route.fulfill({
        status: 200,
        contentType: 'application/json',
        body: JSON.stringify({ success: true, message: 'OTP verified', token: 'mock-token' }),
      });
    });

    await this.submitButton.click();
    await expect(this.otpHeading).toBeVisible();
    await this.enterOtp('0000'); // value irrelevant, network response is mocked
    await this.verifyButton.click();
    await expect(this.otpHeading).toBeHidden();
  }

  /** Real, non-mocked login - requires a human (or a pre-agreed static test OTP) to proceed. */
  async loginWithRealOtp(phone: string, otp: string) {
    await this.openLoginModal();
    await this.enterPhoneNumber(phone);
    await this.submitPhoneNumber();
    await this.enterOtp(otp);
    await this.verify();
    await expect(this.otpHeading).toBeHidden();
  }

  async isLoggedIn(): Promise<boolean> {
    return (await this.loggedInAccountMenu.count()) > 0;
  }
}
