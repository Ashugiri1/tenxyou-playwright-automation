import { Page, Locator, expect } from '@playwright/test';
import { BasePage } from './BasePage';

/** ProductPage (PDP) - e.g. /product/native-bombay-blues-white-blue */
export class ProductPage extends BasePage {
  readonly productTitle: Locator;
  readonly sizeButtons: Locator;
  readonly colorSwatches: Locator;
  readonly addToKitButton: Locator;
  readonly price: Locator;
  readonly pincodeInput: Locator;

  constructor(page: Page) {
    super(page);
    this.productTitle = page.locator('h1');
    this.sizeButtons = page.locator('text=Sizes').locator('xpath=following::button').filter({ hasText: /^\d{1,2}$/ });
    this.colorSwatches = page.locator('text=Colors').locator('xpath=following::img[1]');
    this.addToKitButton = page.getByRole('button', { name: /ADD TO KIT/i });
    this.price = page.locator('text=/^₹\\s?[\\d,]+/').first();
    this.pincodeInput = page.getByPlaceholder(/Enter Pincode/i);
  }

  async selectSize(size: string) {
    const sizeBtn = this.page.getByRole('button', { name: size, exact: true });
    await expect(sizeBtn).toBeVisible();
    await sizeBtn.click();
    await expect(sizeBtn).toHaveClass(/selected|active/i).catch(() => {
      // Fallback: some UIs indicate selection via aria-pressed instead of a class
    });
  }

  async getPriceText(): Promise<string> {
    await expect(this.price).toBeVisible();
    return (await this.price.innerText()).trim();
  }

  async addToKit() {
    const response = await this.waitForApiResponse(/cart|kit/i, async () => {
      await this.addToKitButton.click();
    });
    return response;
  }

  /** Clicks Add to Kit exactly `times` times in rapid succession - used for the duplicate-action test. */
  async rapidAddToKit(times = 2) {
    const clicks = Array.from({ length: times }, () => this.addToKitButton.click({ trial: false }));
    await Promise.allSettled(clicks);
  }
}
