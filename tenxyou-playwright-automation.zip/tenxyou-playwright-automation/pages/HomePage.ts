import { Page, Locator, expect } from '@playwright/test';
import { BasePage } from './BasePage';

/** HomePage - top nav + entry point into a product listing/PDP */
export class HomePage extends BasePage {
  readonly nativeCoorgNav: Locator;
  readonly newLaunchesNav: Locator;
  readonly menNav: Locator;
  readonly womenNav: Locator;
  readonly apparelNav: Locator;
  readonly searchIcon: Locator;
  readonly wishlistIcon: Locator;
  readonly cartIcon: Locator;
  readonly buyNowHeroButton: Locator;
  readonly productCards: Locator;

  constructor(page: Page) {
    super(page);
    this.nativeCoorgNav = page.getByRole('link', { name: 'Native - Coorg' });
    this.newLaunchesNav = page.getByRole('link', { name: 'New Launches' });
    this.menNav = page.getByRole('link', { name: 'Men', exact: true });
    this.womenNav = page.getByRole('link', { name: 'Women', exact: true });
    this.apparelNav = page.getByRole('link', { name: 'Apparel' });

    this.searchIcon = page.locator('header').getByRole('button', { name: /search/i })
      .or(page.locator('[aria-label*="search" i]').first());
    this.wishlistIcon = page.locator('header').getByRole('button', { name: /wishlist/i })
      .or(page.locator('[aria-label*="wishlist" i]').first());
    this.cartIcon = page.locator('header').getByRole('button', { name: /cart|kit|bag/i })
      .or(page.locator('[aria-label*="cart" i], [aria-label*="bag" i]').first());

    this.buyNowHeroButton = page.getByRole('button', { name: /BUY NOW/i }).first();
    this.productCards = page.locator('a[href*="/product/"]');
  }

  async open() {
    await this.goto('/');
    await expect(this.page).toHaveTitle(/Ten x You/i);
  }

  async openProductByIndex(index = 0) {
    const card = this.productCards.nth(index);
    await expect(card).toBeVisible();
    await card.click();
    await this.page.waitForLoadState('domcontentloaded');
  }

  async openProductByUrl(productPath: string) {
    await this.goto(productPath);
    await this.page.waitForLoadState('domcontentloaded');
  }

  async openCart() {
    await this.cartIcon.click();
  }
}
