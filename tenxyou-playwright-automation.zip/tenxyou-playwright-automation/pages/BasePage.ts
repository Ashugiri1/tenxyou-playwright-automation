import { Page, expect } from '@playwright/test';

/**
 * BasePage
 * Holds helpers shared by every page object.
 * IMPORTANT: no `waitForTimeout` anywhere in this project. All waits below are
 * condition-based (network response / element state), as required by the assignment.
 */
export class BasePage {
  constructor(protected readonly page: Page) {}

  async goto(path: string = '/') {
    await this.page.goto(path, { waitUntil: 'domcontentloaded' });
  }

  /**
   * Waits for a specific backend API call to complete and returns its JSON response.
   * Used instead of fixed waits whenever UI state depends on an async network call.
   */
  async waitForApiResponse(urlPattern: string | RegExp, action: () => Promise<void>) {
    const [response] = await Promise.all([
      this.page.waitForResponse((res) => {
        const url = res.url();
        return typeof urlPattern === 'string' ? url.includes(urlPattern) : urlPattern.test(url);
      }),
      action(),
    ]);
    return response;
  }

  /** Waits until an element's text stabilizes (e.g. cart total after an async price recalculation). */
  async waitForStableText(locatorSelector: string) {
    const locator = this.page.locator(locatorSelector);
    await expect(locator).toBeVisible();
    let previous = await locator.innerText();
    await expect
      .poll(async () => {
        const current = await locator.innerText();
        const stable = current === previous;
        previous = current;
        return stable;
      }, { timeout: 8000, intervals: [200, 300, 500] })
      .toBe(true);
  }

  async takeScreenshot(name: string) {
    await this.page.screenshot({ path: `test-results/screenshots/${name}.png`, fullPage: true });
  }

  log(message: string) {
    // Centralized console logger - required for "Debugging & Observability"
    // eslint-disable-next-line no-console
    console.log(`[${new Date().toISOString()}] ${message}`);
  }
}
