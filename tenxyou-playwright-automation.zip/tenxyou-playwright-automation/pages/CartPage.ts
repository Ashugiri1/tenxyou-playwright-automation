import { Page, Locator, expect } from '@playwright/test';
import { BasePage } from './BasePage';

/** CartPage - "Your Kit" side drawer shown in the product/cart screenshots */
export class CartPage extends BasePage {
  readonly kitHeading: Locator;
  readonly itemCountLabel: Locator;
  readonly cartItemRow: Locator;
  readonly quantityValue: Locator;
  readonly increaseQtyButton: Locator;
  readonly decreaseQtyButton: Locator;
  readonly removeItemIcon: Locator;
  readonly totalPrice: Locator;
  readonly checkoutButton: Locator;
  readonly couponInput: Locator;
  readonly emptyKitMessage: Locator;

  constructor(page: Page) {
    super(page);
    this.kitHeading = page.getByText(/Your Kit/i);
    this.itemCountLabel = page.getByText(/\d+\s+Item/i);
    this.cartItemRow = page.locator('[class*="cart-item" i], [class*="kit-item" i]')
      .or(page.locator('text=Size :').locator('xpath=ancestor::div[1]'));

    this.quantityValue = page.locator('button:has-text("-")').locator('xpath=following-sibling::*[1]');
    this.increaseQtyButton = page.getByRole('button', { name: '+' });
    this.decreaseQtyButton = page.getByRole('button', { name: '-' });
    this.removeItemIcon = page.locator('[aria-label*="remove" i], [aria-label*="delete" i]').first();

    this.totalPrice = page.getByText(/Total Price/i).locator('xpath=following-sibling::*[1]');
    this.checkoutButton = page.getByRole('button', { name: /CHECKOUT/i });
    this.couponInput = page.getByPlaceholder(/Enter Coupon Code/i);
    this.emptyKitMessage = page.getByText(/your kit is empty|no items/i);
  }

  async open() {
    await expect(this.kitHeading).toBeVisible();
  }

  async getQuantity(): Promise<number> {
    const text = (await this.quantityValue.innerText()).trim();
    return Number(text) || 0;
  }

  async increaseQuantity() {
    const before = await this.getQuantity();
    await this.waitForApiResponse(/cart|kit|update/i, async () => {
      await this.increaseQtyButton.click();
    });
    await expect
      .poll(async () => this.getQuantity(), { timeout: 8000 })
      .toBe(before + 1);
  }

  async decreaseQuantity() {
    const before = await this.getQuantity();
    await this.waitForApiResponse(/cart|kit|update/i, async () => {
      await this.decreaseQtyButton.click();
    });
    await expect
      .poll(async () => this.getQuantity(), { timeout: 8000 })
      .toBe(Math.max(before - 1, 0));
  }

  async removeItem() {
    await this.waitForApiResponse(/cart|kit|remove|delete/i, async () => {
      await this.removeItemIcon.click();
    });
  }

  async getTotalPriceText(): Promise<string> {
    await this.waitForStableText('text=Total Price >> xpath=following-sibling::*[1]').catch(() => {});
    return (await this.totalPrice.innerText()).trim();
  }

  async isEmpty(): Promise<boolean> {
    return (await this.emptyKitMessage.count()) > 0;
  }
}
