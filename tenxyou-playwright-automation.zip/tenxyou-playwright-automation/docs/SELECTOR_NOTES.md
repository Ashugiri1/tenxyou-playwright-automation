# Selector Notes — READ BEFORE RUNNING AGAINST LIVE SITE

`tenxyou.com` is a client-side-rendered React/Next.js app. The environment this project was
authored in could only fetch the site's initial (pre-hydration) HTML — it could not execute
JavaScript to inspect the fully rendered DOM, real `data-testid`s, or exact class names.

To keep the suite honest, every locator was built from **visible, stable text and ARIA roles**
captured directly from the 5 screenshots provided in the assignment (not guessed from memory):

| Element | Locator strategy used | Source |
|---|---|---|
| Login modal trigger | `header` + role button matching /account/i | header icon row (search/wishlist/account/cart) |
| Phone input | `getByPlaceholder(/Enter Phone Number/i)` | Screenshot 4 |
| Submit button | `getByRole('button', { name: /^SUBMIT$/i })` | Screenshot 4 |
| OTP heading | `getByText(/OTP VERIFICATION/i)` | Screenshot 5 |
| OTP boxes | first 4 single-char text/tel/number inputs after heading | Screenshot 5 |
| Verify button | `getByRole('button', { name: /^VERIFY$/i })` | Screenshot 5 |
| Add to Kit | `getByRole('button', { name: /ADD TO KIT/i })` | Screenshot 2 |
| Sizes | buttons with exact numeric text (6–12) after "Sizes" label | Screenshot 2 |
| Kit heading | `getByText(/Your Kit/i)` | Screenshot 3 |
| Quantity +/- | `getByRole('button', { name: '+' \| '-' })` | Screenshot 3 |
| Checkout | `getByRole('button', { name: /CHECKOUT/i })` | Screenshot 3 |
| Coupon input | `getByPlaceholder(/Enter Coupon Code/i)` | Screenshot 3 |

## Elements NOT visible in any screenshot (best-effort / needs confirmation)
- **Logout control** — no screenshot shows the logged-in account menu. `LoginPage`/persistence
  spec falls back to clearing cookies/localStorage to simulate logout if no logout button is
  found. **Action required:** run `npm run codegen`, log in manually, open the account menu,
  and update `docs/EXECUTION_NOTES.md` + the logout selector once confirmed.
- **Remove-item icon** in the kit drawer — assumed to be an icon button near each line item
  (edit-pencil icon is visible for editing; a separate delete affordance is likely on scroll/
  hover and wasn't captured). **Action required:** confirm via codegen.
- **API endpoint names** — `/cart|kit/i` and `/otp|verify/i` are regex guesses based on common
  naming. **Action required:** open DevTools → Network while performing each action manually
  and replace the regex with the exact path (e.g. `/api/cart/add`).

## How to finalize selectors (required before final submission)
```bash
npm install
npm run codegen
```
This opens an Inspector against the live site. Perform each flow manually once, copy the
generated locators, and reconcile them with the ones in `pages/*.ts`. Update any that differ.
