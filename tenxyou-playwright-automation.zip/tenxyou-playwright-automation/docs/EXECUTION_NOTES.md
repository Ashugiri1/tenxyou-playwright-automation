# Execution Notes — Bugs, Observations & Assumptions

This is the "short explanation" required by the assignment. **Fill in the bracketed
placeholders below after your actual local run** — this file is intentionally structured so
you drop in real findings from `npx playwright test --headed` and the HTML/trace report,
rather than fabricated ones.

## What issues/bugs did you observe?
- [ ] Example format: "Clicking `+` twice quickly on the quantity control caused the total
  price to flash the old value for ~400ms before settling — no loading indicator shown."
- [ ] Example: "Removing the only item in the kit left the drawer showing '1 Item' in the
  header for a moment after the row disappeared — count and content are updated by two
  separate, non-atomic state updates."
- Run `npm run test:duplicate` and `npm run test:multisession` first — these are the two
  scenarios most likely to surface real bugs, per the assignment's own emphasis on state
  transitions.

## Where did the system behave unexpectedly?
- [ ] Fill in after running EC-08 (multi-session conflict) — note whether session A's cart
  reconciles to server truth after refresh, or keeps showing stale data.
- [ ] Fill in after running EC-07 (decrease quantity from 1) — note whether the `-` button
  disables, removes the item, or no-ops.

## What assumptions did you make that failed?
1. **OTP login is not automatable end-to-end on a production site.** Assumed a real SMS OTP
   could be entered programmatically — it cannot, since Playwright has no access to the phone
   receiving the SMS. **Mitigation implemented:** `LoginPage.loginWithMockedOtp()` intercepts
   the verify-OTP network call and mocks a success response, so downstream cart/session tests
   remain fully automated. For a *true* end-to-end login test, you need either (a) a backend
   test account with a static/whitelisted OTP, or (b) manual OTP entry via `test:debug` /
   `--headed` mode with a real phone.
2. **Assumed exact selectors could be inspected from the live DOM.** The authoring environment
   could only fetch pre-hydration HTML for `tenxyou.com` (client-rendered SPA), so several
   selectors (logout control, remove-item icon, exact API paths) are best-effort from
   screenshots only. See `SELECTOR_NOTES.md` — **this must be reconciled with `codegen`
   locally before the suite is considered final.**
3. **Assumed cart is server-persisted per logged-in user (TC-11 / EC-08).** This is the
   industry-standard pattern, but it's unverified for this specific app — the persistence and
   multi-session specs are written to assert this and will fail loudly (not silently pass) if
   the real behavior is session/localStorage-scoped instead.

## Deliverable checklist
- [x] Test Case Document (`docs/TEST_CASES.md`)
- [x] Playwright code (POM, fixtures, 6 spec files)
- [ ] Execution recording — record locally with `npx playwright test --project=chromium
      --headed` (video auto-saved to `test-results/` per `playwright.config.ts`, or use
      `npm run test:ui` and export the trace)
- [x] This short explanation
- [x] AI usage documentation (`docs/AI_USAGE.md`)
