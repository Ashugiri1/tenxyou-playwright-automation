# Test Case Document — tenxyou.com

Scope: Login → Browse → Add to Cart → Modify Cart → Logout/Login → State Persistence.
Focus is on **state transitions**, not just linear steps.

---

## 1. Core Flow

| ID | Title | Steps | Expected Result | Priority |
|----|-------|-------|------------------|----------|
| TC-01 | Open login modal | Click account icon in header | Phone-number modal appears with T&C checkbox and Submit button | High |
| TC-02 | Submit phone number | Enter valid 10-digit number → Submit | OTP screen appears, shows last 4 digits of number, "Resend OTP in 30s" timer starts | High |
| TC-03 | Enter valid OTP | Fill all 4 OTP boxes → Verify | User authenticated, modal closes, account state updates in header | High |
| TC-04 | Browse product | Navigate via nav bar (Men/Women/Native-Coorg) or product card | PDP loads with images, sizes, colors, price, spotlight info | Medium |
| TC-05 | Select size & add to kit | Select a size → click "ADD TO KIT" | Item added; "Your Kit" drawer opens/updates with 1 item, correct size/color/price | High |
| TC-06 | Increase quantity | In kit, click `+` | Quantity increments by 1; **Total Price recalculates** (not just item count) | High |
| TC-07 | Decrease quantity | In kit, click `-` | Quantity decrements by 1; price recalculates; qty never goes below 1 via `-` (edge case, see below) | High |
| TC-08 | Remove item | Click remove/delete icon on item | Item removed; kit shows empty state if it was the only item | High |
| TC-09 | Logout | Trigger logout from account menu | Session ends; protected UI (kit/account) reflects logged-out state | Medium |
| TC-10 | Re-login, same user | Login again with same phone number | User re-authenticated | High |
| TC-11 | Cart state persistence | After TC-10, open kit | Cart should show the same items/quantities as before logout (or documented alternative behavior) | **Critical** |

---

## 2. Edge Cases (state-transition focused)

| ID | Title | Steps | Expected Result | Priority |
|----|-------|-------|------------------|----------|
| EC-01 | Double-click "Add to Kit" | Rapidly double-click Add to Kit on same size/color | Should NOT create two separate line items; quantity should reflect intended single/double add clearly, not silently corrupt state | High |
| EC-02 | Retry after failed request | Force first "add to cart" call to fail (network abort), then retry | Only one successful item add — no duplication from the retried call | High |
| EC-03 | Page refresh mid-add | Click "Add to Kit", refresh page immediately after click but before response | On reload, cart should reflect only completed operations — no partial/corrupt state | Medium |
| EC-04 | Page refresh in OTP screen | Reach OTP screen, refresh page | Should NOT silently log the user in; either returns to phone-entry or preserves OTP context safely | Medium |
| EC-05 | Delayed UI update (throttled network) | Throttle network, perform add-to-cart | UI must show a clear loading/pending state, not a stale price/quantity, until the response resolves | Medium |
| EC-06 | Session expiry mid-cart-edit | Simulate expired auth token during a cart update call | User should be prompted to re-auth, not silently lose the update or crash | Medium |
| EC-07 | Decrease quantity from 1 | Click `-` when quantity is already 1 | Either removes the item, disables the button, or is a no-op — behavior must be explicit and consistent, not undefined | Medium |
| EC-08 | Multi-session conflict | Same user, 2 browser contexts; add in one, remove in other | On refresh, the "losing" session should reconcile to server truth, not show contradictory state indefinitely | **Critical** |
| EC-09 | Invalid OTP | Enter incorrect OTP | Clear inline error; user remains on OTP screen; no partial auth state granted | High |
| EC-10 | Add to kit while logged out | Try Add to Kit without being logged in | Either prompts login first, or allows guest-cart then merges on login — behavior must be documented, not assumed | Medium |

---

## 3. API-Level Checks

| ID | Title | Steps | Expected Result |
|----|-------|-------|------------------|
| API-01 | Add-to-cart payload | Inspect POST request when clicking "Add to Kit" | Payload includes correct product id, size, color, quantity |
| API-02 | Add-to-cart response vs UI | Compare API response body to what renders in the kit drawer | Price, size, quantity in response match UI exactly |
| API-03 | Quantity-update response | Inspect PATCH/POST on `+`/`-` click | Response's updated quantity/price matches what's rendered, with no extra async delay unaccounted for |

---

## 4. Out of Scope / Assumptions
- Real SMS OTP delivery is **not** automatable end-to-end without a whitelisted test number or backend hook — see `EXECUTION_NOTES.md`.
- Payment/checkout completion is out of scope (kit/cart state is the focus per the assignment).
- Exact selector names (`data-testid`s) could not be inspected directly since the site is a client-rendered SPA not reachable from the sandboxed automation environment used to draft this suite — see `SELECTOR_NOTES.md` for how to finalize them locally with `codegen`.
