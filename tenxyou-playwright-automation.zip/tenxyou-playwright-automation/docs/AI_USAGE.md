# AI Usage Documentation

This assignment was built with Claude (Anthropic) as an AI pair-programmer. Below is a
transparent breakdown of where and how it was used.

## 1. Writing Test Cases
- Gave Claude the assignment brief + product screenshots (homepage, PDP, "Your Kit" drawer,
  phone-login modal, OTP modal).
- Asked it to enumerate **state-transition-focused** test cases rather than a flat step list —
  e.g. explicitly calling out "decrease quantity from 1", "refresh mid-add", "OTP screen
  refresh" as edge cases, since these are the kind of transitions that break real apps.
- Reviewed and trimmed the generated list to keep it relevant to what's visible in the
  screenshots (removed cases about features not shown, like wishlist-to-cart flows).

## 2. Improving Selectors
- Because the automation environment could not execute JavaScript on the live site (sandboxed
  network), Claude built selectors using Playwright's **recommended resilient strategies**
  first: `getByRole`, `getByPlaceholder`, `getByText` — matching against real, visible text
  captured in the screenshots ("ADD TO KIT", "Enter Phone Number", "OTP VERIFICATION",
  "Your Kit", "CHECKOUT") — instead of brittle `nth-child`/CSS-position selectors.
- Explicitly flagged every locator that is a best-effort guess in `SELECTOR_NOTES.md`, with
  instructions to re-derive exact selectors using `npx playwright codegen` before a real CI run.
- This is a case where AI accelerated the *pattern* (locator strategy, POM structure) but a
  human still needs to run codegen once against the live app to lock in exact strings — I did
  not let the AI "hallucinate" a `data-testid` that isn't confirmed to exist.

## 3. Debugging Issues
- Used Claude to design the wait strategy: instead of `waitForTimeout`, we use
  `page.waitForResponse()` keyed to the relevant cart/OTP API pattern, and `expect.poll()` for
  UI values that update asynchronously after a network call resolves (e.g. cart total).
- Used it to reason through the OTP-login blocker: a production site's real SMS OTP cannot be
  read by Playwright. Solution designed with AI assistance: intercept and mock the OTP-verify
  network call (`page.route`) so the rest of the suite (cart, persistence, multi-session) stays
  fully automatable and deterministic, while keeping a `loginWithRealOtp()` path available for
  a human-in-the-loop or whitelisted-test-number scenario.

## Where AI did NOT replace judgment
- Every locator, wait, and assertion strategy above was reviewed against Playwright best
  practices before inclusion — the AI proposed, a human (me) verified against the actual
  assignment rules ("no waitForTimeout", "no fragile nth-child").
- Final selector validation against the *live* DOM still needs to happen locally (documented as
  a required step, not skipped).
