import { test, expect } from '../fixtures/test-fixtures';
import { TestData } from '../utils/test-data';

/**
 * Scenario E - Persistence Test
 * Add items -> Logout -> Login again -> validate cart state is preserved (server-side cart)
 * or document the actual (possibly session-scoped) behaviour observed.
 */
test.describe('Cart Persistence Across Sessions', () => {
  test('cart state persists after logout and re-login for the same user', async ({
    page,
    homePage,
    loginPage,
    productPage,
    cartPage,
  }) => {
    await homePage.open();
    await loginPage.loginWithMockedOtp(TestData.phoneNumber);

    await homePage.openProductByUrl(TestData.product.path);
    await productPage.selectSize(TestData.product.size);
    await productPage.addToKit();
    await cartPage.open();
    const quantityBeforeLogout = await cartPage.getQuantity();
    expect(quantityBeforeLogout).toBeGreaterThan(0);

    // --- Logout ---
    // No dedicated logout button was captured in the provided screenshots; the common pattern
    // for this GoKwik-style auth is an "Account" menu -> "Logout" action. Selector documented
    // in docs/SELECTOR_NOTES.md - verify with codegen before relying on it in CI.
    const logoutTrigger = page.getByRole('button', { name: /logout|sign out/i })
      .or(page.getByText(/logout|sign out/i));
    if (await logoutTrigger.count()) {
      await logoutTrigger.first().click();
    } else {
      // Fallback used when no explicit logout UI is exposed: clear session storage/cookies
      // to simulate a logout and force a fresh auth state.
      await page.context().clearCookies();
      await page.evaluate(() => window.localStorage.clear());
      await page.reload({ waitUntil: 'domcontentloaded' });
    }

    // --- Login again, same user ---
    await homePage.open();
    await loginPage.loginWithMockedOtp(TestData.phoneNumber);

    await homePage.openCart();
    await cartPage.open();

    const quantityAfterReLogin = await cartPage.getQuantity();
    cartPage.log(
      `Persistence check: qty before logout = ${quantityBeforeLogout}, qty after re-login = ${quantityAfterReLogin}`
    );

    // Expected (server-persisted cart for logged-in user): quantities match.
    expect(
      quantityAfterReLogin,
      'Cart should persist across logout/login for the same authenticated user'
    ).toBe(quantityBeforeLogout);
  });
});
