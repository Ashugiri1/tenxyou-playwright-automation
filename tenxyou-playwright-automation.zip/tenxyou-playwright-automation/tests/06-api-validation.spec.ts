import { test, expect } from '../fixtures/test-fixtures';
import { TestData } from '../utils/test-data';

/**
 * API Awareness
 * Captures the "add to cart" network call directly (instead of only asserting UI),
 * and cross-validates the request payload / response against what the UI shows.
 * This is the same technique that would be used to build a Postman collection -
 * here it's done inline via Playwright's request interception for a single source of truth.
 */
test.describe('API Awareness - Cart Endpoint', () => {
  test('add-to-cart request payload and response match what the UI displays', async ({
    page,
    homePage,
    loginPage,
    productPage,
  }) => {
    await homePage.open();
    await loginPage.loginWithMockedOtp(TestData.phoneNumber);
    await homePage.openProductByUrl(TestData.product.path);
    await productPage.selectSize(TestData.product.size);

    let capturedRequestBody: any = null;
    let capturedResponseBody: any = null;

    page.on('request', (request) => {
      if (/cart|kit/i.test(request.url()) && request.method() === 'POST') {
        capturedRequestBody = request.postDataJSON?.() ?? request.postData();
      }
    });

    const response = await productPage.waitForApiResponse(/cart|kit/i, async () => {
      await productPage.addToKit();
    });

    capturedResponseBody = await response.json().catch(() => null);

    productPage.log(`Captured request payload: ${JSON.stringify(capturedRequestBody)}`);
    productPage.log(`Captured response payload: ${JSON.stringify(capturedResponseBody)}`);

    // Basic contract checks - adjust field names once the real payload shape is confirmed
    // via the Network tab (see docs/EXECUTION_NOTES.md for the actual observed schema).
    expect(response.status(), 'Add-to-cart API should respond with a 2xx status').toBeLessThan(300);
    expect(capturedRequestBody, 'Add-to-cart request should include a size selection').toBeTruthy();
  });

  test('quantity update API response reflects the new quantity used by the UI', async ({
    homePage,
    loginPage,
    productPage,
    cartPage,
  }) => {
    await homePage.open();
    await loginPage.loginWithMockedOtp(TestData.phoneNumber);
    await homePage.openProductByUrl(TestData.product.path);
    await productPage.selectSize(TestData.product.size);
    await productPage.addToKit();
    await cartPage.open();

    const response = await cartPage.waitForApiResponse(/cart|kit|update/i, async () => {
      await cartPage.increaseQtyButton.click();
    });
    const body = await response.json().catch(() => null);
    const uiQuantity = await cartPage.getQuantity();

    cartPage.log(`API response after increment: ${JSON.stringify(body)} | UI quantity: ${uiQuantity}`);
    expect(response.ok(), 'Quantity-update API should succeed').toBeTruthy();
    expect(uiQuantity).toBe(2);
  });
});
