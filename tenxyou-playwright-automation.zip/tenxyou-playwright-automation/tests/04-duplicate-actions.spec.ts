import { test, expect } from '../fixtures/test-fixtures';
import { TestData } from '../utils/test-data';

/**
 * Scenario D - Duplicate Action Handling
 * Simulates double-click / rapid retry on "Add to Cart" and asserts the system either
 * de-dupes correctly (quantity increments cleanly) or the behaviour is clearly captured.
 */
test.describe('Duplicate Action Handling', () => {
  test.beforeEach(async ({ homePage, loginPage }) => {
    await homePage.open();
    await loginPage.loginWithMockedOtp(TestData.phoneNumber);
  });

  test('double-clicking "Add to Kit" does not create duplicate line items', async ({
    homePage,
    productPage,
    cartPage,
  }) => {
    await homePage.openProductByUrl(TestData.product.path);
    await productPage.selectSize(TestData.product.size);

    // Fire two near-simultaneous clicks (double-click simulation) and wait for network to settle
    const responsesPromise = Promise.allSettled([
      productPage.waitForApiResponse(/cart|kit/i, () => Promise.resolve()),
    ]);
    await productPage.rapidAddToKit(2);
    await productPage['page'].waitForLoadState('networkidle').catch(() => {});
    await responsesPromise;

    await cartPage.open();

    // Expected: ONE line item, quantity reflects how many add-calls actually succeeded.
    // This assertion documents actual behaviour rather than assuming - see EXECUTION_NOTES.md
    const itemRows = await cartPage.cartItemRow.count();
    cartPage.log(`Duplicate-click result: distinct cart line items = ${itemRows}`);
    expect(itemRows, 'Rapid double-click should not create two SEPARATE line items for the same size/color').toBe(1);
  });

  test('retrying the same add-to-kit action after a network failure does not duplicate', async ({
    homePage,
    productPage,
    cartPage,
    page,
  }) => {
    await homePage.openProductByUrl(TestData.product.path);
    await productPage.selectSize(TestData.product.size);

    // Simulate a failed first attempt (e.g. flaky network), then a successful retry
    let attempt = 0;
    await page.route(/cart|kit/i, async (route) => {
      attempt += 1;
      if (attempt === 1) {
        await route.abort('failed');
      } else {
        await route.continue();
      }
    });

    await productPage.addToKitButton.click().catch(() => {});
    await productPage.addToKitButton.click(); // retry

    await cartPage.open();
    expect(await cartPage.getQuantity()).toBe(1);
  });
});
