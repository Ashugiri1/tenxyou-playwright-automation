import { test, expect } from '../fixtures/test-fixtures';
import { TestData } from '../utils/test-data';

/**
 * Scenario B - Cart Management Flow
 * Add item -> Update quantity -> Remove item, with UI-state and price validations.
 */
test.describe('Cart Management', () => {
  test.beforeEach(async ({ homePage, loginPage }) => {
    await homePage.open();
    await loginPage.loginWithMockedOtp(TestData.phoneNumber);
  });

  test('adding an item shows it in the kit with correct size and price', async ({
    homePage,
    productPage,
    cartPage,
  }) => {
    await homePage.openProductByUrl(TestData.product.path);
    const priceOnPdp = await productPage.getPriceText();

    await productPage.selectSize(TestData.product.size);
    await productPage.addToKit();

    await cartPage.open();
    await expect(cartPage.itemCountLabel).toContainText('1');
    await expect(cartPage.getTotalPriceText()).resolves.toContain(priceOnPdp.replace(/[^\d]/g, '').slice(0, 3));
  });

  test('increasing quantity updates both the count and the total price', async ({
    homePage,
    productPage,
    cartPage,
  }) => {
    await homePage.openProductByUrl(TestData.product.path);
    await productPage.selectSize(TestData.product.size);
    await productPage.addToKit();
    await cartPage.open();

    const totalBefore = await cartPage.getTotalPriceText();
    await cartPage.increaseQuantity();
    const totalAfter = await cartPage.getTotalPriceText();

    expect(await cartPage.getQuantity()).toBe(2);
    expect(totalAfter).not.toEqual(totalBefore); // price must recalculate, not stay frozen
  });

  test('decreasing quantity back to 1 restores the original price', async ({
    homePage,
    productPage,
    cartPage,
  }) => {
    await homePage.openProductByUrl(TestData.product.path);
    await productPage.selectSize(TestData.product.size);
    await productPage.addToKit();
    await cartPage.open();

    const originalTotal = await cartPage.getTotalPriceText();
    await cartPage.increaseQuantity();
    await cartPage.decreaseQuantity();

    expect(await cartPage.getQuantity()).toBe(1);
    expect(await cartPage.getTotalPriceText()).toEqual(originalTotal);
  });

  test('removing the only item empties the kit', async ({ homePage, productPage, cartPage }) => {
    await homePage.openProductByUrl(TestData.product.path);
    await productPage.selectSize(TestData.product.size);
    await productPage.addToKit();
    await cartPage.open();

    await cartPage.removeItem();

    expect(await cartPage.isEmpty()).toBeTruthy();
  });
});
