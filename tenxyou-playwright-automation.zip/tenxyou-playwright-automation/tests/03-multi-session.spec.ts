import { test, expect } from '../fixtures/test-fixtures';
import { TestData } from '../utils/test-data';
import { HomePage } from '../pages/HomePage';
import { LoginPage } from '../pages/LoginPage';
import { ProductPage } from '../pages/ProductPage';
import { CartPage } from '../pages/CartPage';

/**
 * Scenario C - Multi-Session Test
 * Same user logged in via 2 independent BrowserContexts (simulates 2 tabs/devices).
 * Add an item in session 1, modify/remove it in session 2, and observe how/if session 1
 * reflects the change once it re-syncs (on refresh or re-navigation - see docs/EXECUTION_NOTES.md
 * for the actual observed behavior, since this is environment/backend dependent).
 */
test.describe('Multi-Session Behaviour', () => {
  test('cart change in session 2 is (or is not) reflected in session 1 after refresh', async ({ browser }) => {
    const contextA = await browser.newContext();
    const contextB = await browser.newContext();
    const pageA = await contextA.newPage();
    const pageB = await contextB.newPage();

    const sessionA = { home: new HomePage(pageA), login: new LoginPage(pageA), product: new ProductPage(pageA), cart: new CartPage(pageA) };
    const sessionB = { home: new HomePage(pageB), login: new LoginPage(pageB), product: new ProductPage(pageB), cart: new CartPage(pageB) };

    // Both sessions authenticate as the SAME user (mocked OTP, same phone number)
    await sessionA.home.open();
    await sessionA.login.loginWithMockedOtp(TestData.phoneNumber);
    await sessionB.home.open();
    await sessionB.login.loginWithMockedOtp(TestData.phoneNumber);

    // Session A adds an item
    await sessionA.home.openProductByUrl(TestData.product.path);
    await sessionA.product.selectSize(TestData.product.size);
    await sessionA.product.addToKit();
    await sessionA.cart.open();
    expect(await sessionA.cart.getQuantity()).toBe(1);

    // Session B (same user, different context) opens the cart and removes the item
    await sessionB.home.openProductByUrl(TestData.product.path);
    await sessionB.home.openCart();
    await sessionB.cart.open();
    await sessionB.cart.removeItem();
    expect(await sessionB.cart.isEmpty()).toBeTruthy();

    // Session A refreshes to re-sync with backend state
    await pageA.reload({ waitUntil: 'domcontentloaded' });
    await sessionA.home.openCart();

    // ASSERT + OBSERVE: cart is expected to be SERVER-SYNCED for a logged-in user, so after
    // a full page reload session A should see the same empty state as session B. If this
    // fails, it is a real, reportable finding (client cache not invalidated on cross-session
    // change) - documented either way in docs/EXECUTION_NOTES.md.
    const isEmptyInA = await sessionA.cart.isEmpty();
    sessionA.cart.log(`Multi-session sync result: session A empty after B removed item = ${isEmptyInA}`);
    expect(isEmptyInA, "Expected session A to reflect session B's removal after refresh (server-synced cart)").toBeTruthy();

    await contextA.close();
    await contextB.close();
  });
});
