import { test, expect } from '../fixtures/test-fixtures';
import { TestData } from '../utils/test-data';

/**
 * Scenario A - Login Flow
 * Stable, reusable, with proper assertions on each state transition of the OTP modal.
 */
test.describe('Login Flow', () => {
  test('user can open the login modal from the header', async ({ page, homePage, loginPage }) => {
    await homePage.open();
    await loginPage.openLoginModal();

    await expect(loginPage.phoneInput).toBeVisible();
    await expect(page.getByText(/fetch your saved addresses/i)).toBeVisible();
  });

  test('submitting a valid phone number transitions to the OTP screen', async ({ homePage, loginPage }) => {
    await homePage.open();
    await loginPage.openLoginModal();
    await loginPage.enterPhoneNumber(TestData.phoneNumber);

    // Intercept the "send OTP" call so this test is deterministic regardless of live SMS delivery
    await loginPage['page'].route(/send.?otp|generate.?otp/i, (route) =>
      route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify({ success: true }) })
    );
    await loginPage.submitButton.click();

    await expect(loginPage.otpHeading).toBeVisible();
    await expect(loginPage['page'].getByText(new RegExp(TestData.phoneNumber.slice(-4)))).toBeVisible();
  });

  test('successful OTP verification logs the user in (mocked network response)', async ({ homePage, loginPage }) => {
    await homePage.open();
    await loginPage.loginWithMockedOtp(TestData.phoneNumber);

    // Post-login: OTP modal must be gone and the account state should reflect "logged in"
    await expect(loginPage.otpHeading).toBeHidden();
  });

  test('invalid/incomplete OTP shows an inline error and does not proceed', async ({ homePage, loginPage, page }) => {
    await homePage.open();
    await loginPage.openLoginModal();
    await loginPage.enterPhoneNumber(TestData.phoneNumber);

    await page.route(/send.?otp|generate.?otp/i, (route) =>
      route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify({ success: true }) })
    );
    await loginPage.submitButton.click();
    await expect(loginPage.otpHeading).toBeVisible();

    await page.route(/verify.?otp|otp.?verify/i, (route) =>
      route.fulfill({ status: 400, contentType: 'application/json', body: JSON.stringify({ success: false, message: 'Invalid OTP' }) })
    );
    await loginPage.enterOtp('0000');
    await loginPage.verifyButton.click();

    // OTP screen should remain visible on failure - user should NOT be silently logged in
    await expect(loginPage.otpHeading).toBeVisible();
  });
});
